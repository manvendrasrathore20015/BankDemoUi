from preprocessingfolder import preprocessingfile
import pandas as pd
import numpy as np
import joblib
import pickle
from Data_ingestion import data_ingestion

class predict():
    def __init__(self):
        pass

    def predictor(self,file):
        instance1 = data_ingestion.data_getter()
        data = instance1.data_load(file)

        instance2 = preprocessingfile.preprocess()

        set=instance2.initialize_columns(data)
        set1 = instance2.new_feature(set)
        set2=instance2.drop_columns(set1)

        encoded_data = instance2.encoder(set2)

        model = joblib.load('pickle_files/fraud_detect_priyank.pkl')
        ss = joblib.load('pickle_files/Stand_scaler_priyank.pkl')

        ss_result = ss.fit_transform(encoded_data)
        result = model.predict(ss_result)

        encoded_data['output'] = result

        return encoded_data

class LA_predict():
    def __init__(self):
        pass

    def predictor(self,file):
        instance1 = data_ingestion.data_getter()
        data = instance1.data_load(file)

        instance2 = preprocessingfile.LA_preprocess()

        set0 = instance2.initialize_columns(data)
        set1 = instance2.imputer(set0)
        set2 = instance2.drop_Loan_id(set1)
        encoded_data = instance2.encode_cat_f(set2)
        new_data = instance2.drop_columns(encoded_data)

        ss_LA = pickle.load(open('pickle_files/veena_LA_stan_scaler.pkl', 'rb'))
        model_LA=pickle.load(open('pickle_files/LAOpt8model.sav', 'rb'))

        ss_result = ss_LA.fit_transform(new_data)
        result = model_LA.predict(ss_result)

        new_data['output'] = result

        return new_data







